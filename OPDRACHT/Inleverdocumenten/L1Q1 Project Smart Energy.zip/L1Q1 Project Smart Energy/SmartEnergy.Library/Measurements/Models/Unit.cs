namespace SmartEnergy.Library.Measurements.Models;

public enum Unit
{
    KilowattHour,
    CubicMeter,
    Watt
}
